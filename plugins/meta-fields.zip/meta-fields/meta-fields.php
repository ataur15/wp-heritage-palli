<?php
/**
 * Plugin Name: Meta Fields
 * Plugin URI:
 * Description: Banner Meta Fields
 * Version: 1.0.0
 * Author: Ataur Rahman
 * Author URI: https://profiles.wordpress.org/mdataur/
 * License: GPLv2
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain: meta-fields
 * Domain Path: /languages
 */

defined( 'ABSPATH' ) or die( 'No script kiddies please!' );

use Carbon_Fields\Container;
use Carbon_Fields\Field;

if (!class_exists('MetaFields')) {
    class MetaFields {
        // Constructor
        function __construct(){
            add_action( 'plugins_loaded', array($this, 'metafields_loaded') );
			// add_action( 'wp_enqueue_scripts', array($this, 'metafields_load_scripts') );
            add_action( 'carbon_fields_register_fields', array($this, 'metafields_attach_theme_options') );
            add_shortcode( 'meta_fields', array($this, 'meta_fields_shortcode') );
        }

        // Text domain loaded
        function metafields_loaded() {
            require( __DIR__ . '/vendor/autoload.php' );
            \Carbon_Fields\Carbon_Fields::boot();
            load_plugin_textdomain( 'meta-fields', false, dirname( plugin_basename( __FILE__ ) ) . '/languages' );
        }

        // Carbon fields
        function metafields_attach_theme_options() {
            Container::make( 'theme_options', __( 'Meta Fields' ) )
                ->add_fields( array(
                    Field::make( 'complex', 'metafields', __( 'Banner' ) )
                        ->set_layout('tabbed-vertical')
                        ->add_fields(array(
                            Field::make( 'text', 'product_name', __( 'Product Name' ) ),
                            Field::make( 'text', 'sub_name', __( 'Sub Name' ) ),
                            Field::make( 'text', 'link', __( 'Link' ) ),
                            Field::make( 'image', 'image', __( 'Image' ) ),
                        ) )
                ) );
        }

        // Data display
        public static function meta_fields_display() { ?>
            <?php if ( function_exists( 'carbon_field_exists' ) ) {
                $fields = carbon_get_theme_option( 'metafields' );
                foreach($fields as $field) {
                    $imageId = $field['image'];
                    $imgSrc = wp_get_attachment_image_src($imageId, 'full');
                    ?>
                    <div class="banner-bar">
                        <a href="<?php echo $field['link']; ?>">
                            <img class="image-hover" src="<?php echo esc_url($imgSrc[0]); ?>" alt="">
                        </a>
                        <div class="tooltip">
                            <p><a href="<?php echo $field['link']; ?>"><?php echo $field['product_name']; ?></a></p>
                            <p><?php echo $field['sub_name']; ?></p>
                        </div>
                    </div>
                    <?php
                }
            }
        }

        // Shortcode
        function meta_fields_shortcode() {
            // Turn on output buffering.
			ob_start();

			// echo slider
			self::meta_fields_display();

			// Turn off output buffering
			return ob_get_clean();
        }
    }

    new MetaFields;
}
