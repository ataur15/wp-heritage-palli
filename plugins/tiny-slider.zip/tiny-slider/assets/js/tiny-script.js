var slider = tns({
    container: '.tiny-slider',
    items: 1,
    mode: 'gallery',
    slideBy: 'page',
    autoplay: true,
    nav: true,
    navPosition: 'bottom',
    autoplayButtonOutput: false,
    controls: false,
});