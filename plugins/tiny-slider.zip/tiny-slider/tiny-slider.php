<?php
/**
 * Plugin Name: Tiny Slider
 * Plugin URI:
 * Description: Tiny slider
 * Version: 1.0.0
 * Author: Ataur Rahman
 * Author URI: https://profiles.wordpress.org/mdataur/
 * License: GPLv2
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain: tiny-slider
 * Domain Path: /languages
 */

defined( 'ABSPATH' ) or die( 'No script kiddies please!' );

use Carbon_Fields\Container;
use Carbon_Fields\Field;

if (!class_exists('TinySlider')) {
    class TinySlider {
        // Constructor
        function __construct(){
            add_action( 'plugins_loaded', array($this, 'ts_loaded') );
			add_action( 'wp_enqueue_scripts', array($this, 'ts_load_scripts') );
            add_action( 'carbon_fields_register_fields', array($this, 'ts_attach_theme_options') );
            add_shortcode( 'tiny_slider', array($this, 'tiny_slider_shortcode') );
        }

        // Text domain loaded
        function ts_loaded() {
            require( __DIR__ . '/vendor/autoload.php' );
            \Carbon_Fields\Carbon_Fields::boot();
            load_plugin_textdomain( 'tiny-slider', false, dirname( plugin_basename( __FILE__ ) ) . '/languages' );
        }

        // Load enqueue scripts
        public function ts_load_scripts(){
            wp_enqueue_style( 'tiny-slider', 'https://cdnjs.cloudflare.com/ajax/libs/tiny-slider/2.9.4/tiny-slider.css' );
            wp_enqueue_style( 'custom-tinyslider', plugin_dir_url( __FILE__ ).'assets/css/custom-tinyslider.css' );
			wp_enqueue_script( 'tiny-slider', 'https://cdnjs.cloudflare.com/ajax/libs/tiny-slider/2.9.2/min/tiny-slider.js', null, time(), true);
            if(is_front_page()){
                wp_enqueue_script( 'tiny-script', plugin_dir_url( __FILE__ ).'assets/js/tiny-script.js', null, time(), true );
            }
		}

        // Carbon fields
        function ts_attach_theme_options() {
            Container::make( 'theme_options', __( 'Tiny Slider' ) )
                ->add_fields( array(
                    Field::make( 'complex', 'crb_slider', __( 'Slider' ) )
                        ->add_fields( array(
                            Field::make( 'text', 'title', __( 'Slide Title' ) ),
                            Field::make( 'image', 'photo', __( 'Slide Photo' ) ),
                        ) )
                ) );
        }

        // Data display
        public static function tiny_slider_display() { ?>
            <div class="tiny-slider">
                <?php
                if ( function_exists( 'carbon_field_exists' ) ) {
                    $sliders = carbon_get_theme_option( 'crb_slider' );
                    foreach($sliders as $value){
                        $imageId = $value['photo'];
                        $imgSrc = wp_get_attachment_image_src($imageId, 'full');
                        ?>
                        <div><img src=<?php echo esc_url($imgSrc[0]); ?> alt=""></div>
                        <?php
                    }
                }
                ?>
            </div>
            <?php
        }

        // Shortcode
        function tiny_slider_shortcode() {
            // Turn on output buffering.
			ob_start();

			// echo slider
			self::tiny_slider_display();

			// Turn off output buffering
			return ob_get_clean();
        }
    }

    new TinySlider;
}
